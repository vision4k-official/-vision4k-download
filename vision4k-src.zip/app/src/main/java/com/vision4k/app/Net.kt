package com.vision4k.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object Net {
    fun get(url: String, timeout: Int = 40000): String {
        val con = URL(url).openConnection() as HttpURLConnection
        con.connectTimeout = 15000
        con.readTimeout = timeout
        con.setRequestProperty("User-Agent", "Vision4K/2.0")
        return con.inputStream.bufferedReader().use { it.readText() }
    }
}

object M3u {
    private fun attr(l: String, name: String): String =
        Regex("$name=\"([^\"]*)\"").find(l)?.groupValues?.get(1) ?: ""

    fun parse(url: String): List<Item> {
        val con = URL(url).openConnection() as HttpURLConnection
        con.connectTimeout = 15000
        con.readTimeout = 60000
        con.setRequestProperty("User-Agent", "Vision4K/2.0")
        val out = ArrayList<Item>()
        var name = ""; var group = ""; var logo = ""
        var n = 0
        con.inputStream.bufferedReader().useLines { lines ->
            for (raw in lines) {
                val l = raw.trim()
                if (l.startsWith("#EXTINF")) {
                    name = l.substringAfterLast(",").trim()
                    group = attr(l, "group-title")
                    logo = attr(l, "tvg-logo")
                } else if (l.isNotEmpty() && !l.startsWith("#")) {
                    val low = l.substringBefore("?").lowercase()
                    val g = group.lowercase()
                    val type = when {
                        l.contains("/series/") -> "series"
                        l.contains("/movie/") -> "movies"
                        Regex("(?i)\\bs\\d{1,2}\\s?e\\d{1,3}\\b").containsMatchIn(name) || g.contains("series") ||
                            (g.contains("serie") && !g.contains("serie a")) -> "series"
                        g.contains("movie") || g.contains("film") || g.contains("vod") || g.contains("cinema") ||
                            low.endsWith(".mp4") || low.endsWith(".mkv") || low.endsWith(".avi") -> "movies"
                        else -> "live"
                    }
                    n++
                    out.add(Item("$type:$l", l, name.ifBlank { l }, group.ifBlank { "Uncategorized" }, logo, l, type, n))
                    name = ""; group = ""; logo = ""
                }
            }
        }
        return out
    }
}

object Img {
    private val cache = object : LruCache<String, Bitmap>(20 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val pool = Executors.newFixedThreadPool(4)
    private val ui = Handler(Looper.getMainLooper())

    fun load(url: String?, iv: ImageView) {
        iv.tag = url
        val u = url ?: ""
        if (!u.startsWith("http")) { iv.setImageDrawable(null); return }
        val hit = cache.get(u)
        if (hit != null) { iv.setImageBitmap(hit); return }
        iv.setImageDrawable(null)
        pool.execute {
            try {
                val con = URL(u).openConnection() as HttpURLConnection
                con.connectTimeout = 8000
                con.readTimeout = 8000
                val bytes = con.inputStream.use { it.readBytes() }
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                var s = 1
                while (o.outWidth / (s * 2) >= 300 && o.outHeight / (s * 2) >= 300) s *= 2
                val o2 = BitmapFactory.Options()
                o2.inSampleSize = s
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
                if (bmp != null) {
                    cache.put(u, bmp)
                    ui.post { if (iv.tag == u) iv.setImageBitmap(bmp) }
                }
            } catch (e: Exception) { }
        }
    }
}
