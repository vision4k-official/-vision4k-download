package com.vision4k.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class ContentActivity : Activity() {
    data class Row(val key: String, val label: String, val count: Int)

    private var kind = "live"
    private lateinit var pl: Playlist
    private var cats: List<Cat> = emptyList()
    private var all: List<Item> = emptyList()
    private var base: List<Item> = emptyList()
    private val byKey = HashMap<String, Item>()
    private var rows: List<Row> = emptyList()
    private var rowIndex = 1
    private var shown: List<Item> = emptyList()
    private var query = ""
    private var current: Item? = null
    private var player: ExoPlayer? = null
    private val adult = Regex("(?i)(xxx|adult|porn|18\\+)")

    private lateinit var catList: ListView
    private lateinit var itemList: ListView
    private lateinit var statusTv: TextView
    private lateinit var search: EditText
    private var playerView: PlayerView? = null
    private lateinit var titleTv: TextView
    private lateinit var epgBox: LinearLayout
    private var poster: ImageView? = null
    private var infoTv: TextView? = null
    private lateinit var favBtn: Button
    private var itemAdapter: ItemAdapter? = null
    private var catAdapter: CatAdapter? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        immersive()
        kind = intent.getStringExtra("type") ?: "live"
        if (!License.valid(this)) { toast("Your activation has expired"); finish(); return }
        val p = Store.active(this)
        if (p == null) { finish(); return }
        pl = p
        buildUi()
        load()
    }

    private fun aspectMode(): Int = when (Prefs.int(this, "aspect")) { 1 -> 3; 2 -> 4; else -> 0 }

    private fun goTab(target: String?) {
        if (target == null) { finish(); return }
        if (target != kind) {
            startActivity(Intent(this, ContentActivity::class.java).putExtra("type", target))
            finish()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = bgGradient()
        root.setPadding(dp(14), dp(8), dp(14), dp(8))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        fun tab(label: String, target: String?, active: Boolean) {
            val t = tv(label, 20f, if (active) YELLOW else Color.WHITE)
            t.setPadding(dp(14), dp(8), dp(14), dp(8))
            t.isClickable = true
            t.isFocusable = true
            t.setOnClickListener { goTab(target) }
            top.addView(t)
            val sep = View(this)
            sep.setBackgroundColor(0x88FFFFFF.toInt())
            top.addView(sep, lp(dp(1), dp(24)))
        }
        tab("Home", null, false)
        tab("Live", "live", kind == "live")
        tab("Movies", "movies", kind == "movies")
        tab("Series", "series", kind == "series")
        search = field("🔍  Search")
        val sp = lp(0, WRAP, 1f); sp.leftMargin = dp(12); sp.rightMargin = dp(12)
        top.addView(search, sp)
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        top.addView(logo, lp(dp(70), dp(46)))
        root.addView(top, lp(MATCH, WRAP))

        statusTv = tv("Loading...", 14f, SOFT)
        root.addView(statusTv, lp(MATCH, WRAP))

        val body = LinearLayout(this)
        body.orientation = LinearLayout.HORIZONTAL
        catList = ListView(this)
        itemList = ListView(this)
        for (l in listOf(catList, itemList)) {
            l.divider = null
            l.setSelector(ColorDrawable(0x33FFFFFF))
            l.background = round(0x44000000, 10)
        }
        body.addView(catList, lp(0, MATCH, 1.1f))
        val ip = lp(0, MATCH, 1.3f); ip.leftMargin = dp(8); ip.rightMargin = dp(8)
        body.addView(itemList, ip)
        body.addView(rightPanel(), lp(0, MATCH, 1.4f))
        root.addView(body, lp(MATCH, 0, 1f))
        setContentView(root)

        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { query = s.toString(); applyFilter() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        catList.setOnItemClickListener { _, _, pos, _ ->
            val r = rows[pos]
            val go = {
                rowIndex = pos
                catAdapter?.sel = pos
                catAdapter?.notifyDataSetChanged()
                applyFilter()
            }
            if (Prefs.str(this, "pin").isNotEmpty() && adult.containsMatchIn(r.label)) askPin { go() } else go()
        }
        itemList.setOnItemClickListener { _, _, pos, _ -> shown.getOrNull(pos)?.let { onItem(it) } }
        itemList.setOnItemLongClickListener { _, _, pos, _ ->
            shown.getOrNull(pos)?.let { current = it; toggleFav() }
            true
        }
    }

    private fun rightPanel(): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        titleTv = tv("", 19f, Color.WHITE, true)
        titleTv.maxLines = 2
        titleTv.setPadding(0, dp(6), 0, dp(4))
        epgBox = LinearLayout(this)
        epgBox.orientation = LinearLayout.VERTICAL
        if (kind == "live") {
            val pv = PlayerView(this)
            pv.useController = false
            pv.resizeMode = aspectMode()
            pv.setBackgroundColor(Color.BLACK)
            pv.setOnClickListener { current?.let { openItem(it) } }
            playerView = pv
            p.addView(pv, lp(MATCH, 0, 1.25f))
            p.addView(titleTv, lp(MATCH, WRAP))
            p.addView(epgBox, lp(MATCH, 0, 1f))
        } else {
            val ph = ImageView(this)
            ph.scaleType = ImageView.ScaleType.FIT_CENTER
            poster = ph
            p.addView(ph, lp(MATCH, 0, 1.25f))
            p.addView(titleTv, lp(MATCH, WRAP))
            val inf = tv("", 14f, SOFT)
            inf.maxLines = 5
            infoTv = inf
            p.addView(inf, lp(MATCH, 0, 1f))
        }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val playLabel = when (kind) { "series" -> "Episodes"; "movies" -> "Play"; else -> "Fullscreen" }
        val playBtn = btn(playLabel, ACCENT) { current?.let { openItem(it) } }
        favBtn = btn("Add to Favorite", ACCENT2) { toggleFav() }
        val searchBtn = btn("Search", ACCENT2) {
            search.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(search, 0)
        }
        val b1 = lp(0, WRAP, 1f); b1.rightMargin = dp(6)
        val b2 = lp(0, WRAP, 1.3f); b2.rightMargin = dp(6)
        row.addView(playBtn, b1)
        row.addView(favBtn, b2)
        row.addView(searchBtn, lp(0, WRAP, 1f))
        p.addView(row, lp(MATCH, WRAP))
        return p
    }

    private fun load() {
        Thread {
            try {
                val r = Repo.get(pl, kind)
                runOnUiThread {
                    cats = r.first
                    all = r.second
                    byKey.clear()
                    all.forEach { byKey[it.key] = it }
                    if (all.isEmpty()) {
                        statusTv.text = "No $kind found in this playlist (${if (pl.isXtream) "Xtream" else "M3U"}). Check that your subscription includes it."
                        statusTv.visibility = View.VISIBLE
                    } else statusTv.visibility = View.GONE
                    refreshRows()
                    autoStart()
                }
            } catch (e: Exception) {
                runOnUiThread { statusTv.text = "Could not load: ${e.message}" }
            }
        }.start()
    }

    private fun autoStart() {
        if (kind == "live" && Prefs.bool(this, "auto")) {
            val k = Prefs.recent(this, "live").firstOrNull()
            k?.let { byKey[it] }?.let { playPreview(it) }
        }
    }

    private fun refreshRows() {
        val hidden = Prefs.getSet(this, "hide_$kind")
        val hiddenIds = cats.filter { hidden.contains(it.name) }.map { it.id }.toSet()
        base = if (hiddenIds.isEmpty()) all else all.filter { !hiddenIds.contains(it.cat) }
        val counts = base.groupingBy { it.cat }.eachCount()
        val favs = Prefs.getSet(this, "fav")
        val list = ArrayList<Row>()
        list.add(Row("__recent", "Recently Viewed", Prefs.recent(this, kind).count { byKey.containsKey(it) }))
        list.add(Row("__all", "All", base.size))
        list.add(Row("__fav", "Favorite", base.count { favs.contains(it.key) }))
        for (c in cats) if (!hiddenIds.contains(c.id)) list.add(Row(c.id, c.name, counts[c.id] ?: 0))
        rows = list
        if (rowIndex >= rows.size) rowIndex = 1
        val ca = CatAdapter(rows)
        ca.sel = rowIndex
        catAdapter = ca
        catList.adapter = ca
        applyFilter()
    }

    private fun applyFilter() {
        val key = rows.getOrNull(rowIndex)?.key ?: "__all"
        val favs = Prefs.getSet(this, "fav")
        var l: List<Item> = when (key) {
            "__all" -> base
            "__fav" -> base.filter { favs.contains(it.key) }
            "__recent" -> Prefs.recent(this, kind).mapNotNull { byKey[it] }
            else -> base.filter { it.cat == key }
        }
        if (query.isNotBlank()) l = l.filter { it.name.contains(query, true) }
        shown = l
        val ia = ItemAdapter(l)
        ia.cur = current?.key
        itemAdapter = ia
        itemList.adapter = ia
    }

    private fun onItem(item: Item) {
        if (kind == "live") {
            if (current?.key == item.key && player != null) openItem(item) else playPreview(item)
        } else showDetail(item)
    }

    private fun playPreview(item: Item) {
        current = item
        itemAdapter?.cur = item.key
        itemAdapter?.notifyDataSetChanged()
        titleTv.text = item.name
        updateFav()
        if (player == null) {
            val p = ExoPlayer.Builder(this).build()
            player = p
            playerView?.player = p
        }
        player?.setMediaItem(MediaItem.fromUri(Repo.playUrl(this, pl, item)))
        player?.prepare()
        player?.playWhenReady = true
        Prefs.pushRecent(this, "live", item.key)
        loadEpg(item)
    }

    private fun loadEpg(item: Item) {
        epgBox.removeAllViews()
        if (!pl.isXtream) return
        Thread {
            val e = Xt(pl).epg(item.id)
            runOnUiThread {
                if (current?.key == item.key) {
                    epgBox.removeAllViews()
                    e.forEachIndexed { i, ev ->
                        val line = tv("${fmtTime(this, ev.start)} ~ ${fmtTime(this, ev.end)}   ${ev.title}",
                            if (i == 0) 15f else 14f, if (i == 0) YELLOW else Color.WHITE)
                        line.maxLines = 1
                        line.setPadding(0, dp(3), 0, dp(3))
                        epgBox.addView(line)
                    }
                }
            }
        }.start()
    }

    private fun showDetail(item: Item) {
        current = item
        itemAdapter?.cur = item.key
        itemAdapter?.notifyDataSetChanged()
        titleTv.text = item.name
        infoTv?.text = item.info
        poster?.let { Img.load(item.icon, it) }
        updateFav()
    }

    private fun updateFav() {
        val k = current?.key ?: ""
        favBtn.text = if (Prefs.getSet(this, "fav").contains(k)) "Remove Favorite" else "Add to Favorite"
    }

    private fun toggleFav() {
        val c = current ?: return
        val added = Prefs.toggleFav(this, c.key)
        toast(if (added) "Added to Favorites" else "Removed from Favorites")
        updateFav()
        val first = itemList.firstVisiblePosition
        refreshRows()
        itemList.setSelection(first)
    }

    private fun openItem(item: Item) {
        if (kind == "series" && item.url.isEmpty()) { showEpisodes(item); return }
        Prefs.pushRecent(this, kind, item.key)
        if (kind == "live") {
            val list = shown.map { Media(it.name, Repo.playUrl(this, pl, it), it.icon, it.id, true) }
            play(list, shown.indexOfFirst { it.key == item.key }.coerceAtLeast(0))
        } else {
            play(listOf(Media(item.name, Repo.playUrl(this, pl, item), item.icon, item.id, false)), 0)
        }
    }

    private fun play(list: List<Media>, index: Int) {
        if (Prefs.bool(this, "ext")) {
            try {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(Uri.parse(list[index].url), "video/*")
                startActivity(Intent.createChooser(i, "Play with"))
            } catch (e: Exception) { toast("No external player found") }
        } else {
            Queue.list = list
            Queue.idx = index
            startActivity(Intent(this, PlayerActivity::class.java))
        }
    }

    private fun showEpisodes(item: Item) {
        toast("Loading episodes...")
        Thread {
            val eps = Xt(pl).episodes(item.id)
            runOnUiThread {
                if (eps.isEmpty()) toast("No episodes found") else {
                    val media = eps.map { Media("${item.name} - ${it.label}", Xt.episodeUrl(pl, it.id, it.ext), item.icon, "", false) }
                    AlertDialog.Builder(this).setTitle(item.name)
                        .setItems(eps.map { it.label }.toTypedArray()) { _, i ->
                            Prefs.pushRecent(this, "series", item.key)
                            play(media, i)
                        }.show()
                }
            }
        }.start()
    }

    override fun onPause() {
        super.onPause()
        player?.release()
        player = null
        playerView?.player = null
    }

    override fun onResume() {
        super.onResume()
        immersive()
        val c = current
        if (kind == "live" && c != null && player == null && all.isNotEmpty()) playPreview(c)
    }

    private fun textSizeSp(): Float = when (Prefs.int(this, "text", 1)) { 0 -> 14f; 2 -> 19f; else -> 16f }

    private inner class CatAdapter(val list: List<Row>) : BaseAdapter() {
        var sel = -1
        override fun getCount() = list.size
        override fun getItem(position: Int): Any = list[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row: LinearLayout
            if (convertView is LinearLayout) row = convertView else {
                row = LinearLayout(this@ContentActivity)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(12), dp(10), dp(12), dp(10))
                val name = tv("", 16f)
                name.maxLines = 1
                name.ellipsize = TextUtils.TruncateAt.END
                row.addView(name, lp(0, WRAP, 1f))
                row.addView(tv("", 15f, SOFT))
            }
            val r = list[position]
            val on = position == sel
            val n = row.getChildAt(0) as TextView
            n.text = r.label
            n.textSize = textSizeSp()
            n.setTextColor(if (on) YELLOW else Color.WHITE)
            val c = row.getChildAt(1) as TextView
            c.text = r.count.toString()
            c.setTextColor(if (on) YELLOW else SOFT)
            row.setBackgroundColor(if (on) 0x33FFFFFF else 0)
            return row
        }
    }

    private inner class ItemAdapter(val list: List<Item>) : BaseAdapter() {
        var cur: String? = null
        override fun getCount() = list.size
        override fun getItem(position: Int): Any = list[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row: LinearLayout
            if (convertView is LinearLayout) row = convertView else {
                row = LinearLayout(this@ContentActivity)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(8), dp(4), dp(8), dp(4))
                row.minimumHeight = dp(54)
                val num = tv("", 13f, SOFT)
                num.gravity = Gravity.CENTER
                row.addView(num, lp(dp(40), WRAP))
                val img = ImageView(this@ContentActivity)
                img.scaleType = ImageView.ScaleType.FIT_CENTER
                val ilp = lp(dp(44), dp(44)); ilp.rightMargin = dp(8)
                row.addView(img, ilp)
                val name = tv("", 16f)
                name.maxLines = 2
                name.ellipsize = TextUtils.TruncateAt.END
                row.addView(name, lp(0, WRAP, 1f))
            }
            val item = list[position]
            (row.getChildAt(0) as TextView).text = if (item.num > 0) item.num.toString() else ""
            Img.load(item.icon, row.getChildAt(1) as ImageView)
            val n = row.getChildAt(2) as TextView
            val fav = Prefs.getSet(this@ContentActivity, "fav").contains(item.key)
            n.text = (if (fav) "★ " else "") + item.name
            n.textSize = textSizeSp()
            n.setTextColor(if (item.key == cur) YELLOW else Color.WHITE)
            return row
        }
    }
}
