package com.vision4k.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

const val MATCH = -1
const val WRAP = -2
val YELLOW = 0xFFF2C94C.toInt()
val SOFT = 0xFFA9B4C6.toInt()
val TILE = 0xCC2A3650.toInt()
val TILE_FOCUS = 0xFF3F5478.toInt()
val ACCENT = 0xFFC4554D.toInt()
val ACCENT2 = 0xFF4B5F82.toInt()

fun Activity.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

fun Activity.bgGradient() = GradientDrawable(
    GradientDrawable.Orientation.TL_BR,
    intArrayOf(0xFF0D131D.toInt(), 0xFF1A2434.toInt(), 0xFF121A27.toInt())
)

fun Activity.round(color: Int, r: Int = 12): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(r).toFloat()
    return g
}

@Suppress("DEPRECATION")
fun Activity.immersive() {
    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
}

fun Activity.toast(t: String) { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() }

fun Activity.tv(t: String, size: Float = 16f, color: Int = Color.WHITE, bold: Boolean = false): TextView {
    val v = TextView(this)
    v.text = t
    v.textSize = size
    v.setTextColor(color)
    if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
    return v
}

fun Activity.tile(icon: String, label: String, iconSize: Float = 34f, labelSize: Float = 16f,
                  horizontal: Boolean = false, onClick: () -> Unit): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = if (horizontal) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
    l.gravity = Gravity.CENTER
    l.setPadding(dp(10), dp(8), dp(10), dp(8))
    l.background = round(TILE, 12)
    l.isFocusable = true
    l.isClickable = true
    l.setOnFocusChangeListener { v, f ->
        v.background = round(if (f) TILE_FOCUS else TILE, 12)
        v.scaleX = if (f) 1.04f else 1f
        v.scaleY = v.scaleX
    }
    l.setOnClickListener { onClick() }
    val ic = tv(icon, iconSize)
    ic.gravity = Gravity.CENTER
    if (horizontal) ic.setPadding(0, 0, dp(10), 0)
    l.addView(ic)
    val lb = tv(label, labelSize)
    if (horizontal) { lb.maxLines = 2; l.addView(lb, lp(0, WRAP, 1f)) } else { lb.gravity = Gravity.CENTER; l.addView(lb) }
    return l
}

fun Activity.btn(label: String, color: Int, onClick: () -> Unit): Button {
    val b = Button(this)
    b.text = label
    b.setTextColor(Color.WHITE)
    b.textSize = 15f
    b.isAllCaps = false
    b.background = round(color, 10)
    b.isFocusable = true
    b.setOnFocusChangeListener { v, f -> v.alpha = if (f) 1f else 0.85f; v.scaleX = if (f) 1.04f else 1f; v.scaleY = v.scaleX }
    b.setOnClickListener { onClick() }
    return b
}

fun Activity.field(hint: String, pass: Boolean = false): EditText {
    val e = EditText(this)
    e.hint = hint
    e.setHintTextColor(0xFF9A8A8C.toInt())
    e.setTextColor(Color.WHITE)
    e.textSize = 16f
    e.setSingleLine()
    e.setPadding(dp(14), dp(12), dp(14), dp(12))
    e.background = round(0x55888888, 8)
    if (pass) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    return e
}

fun Activity.askPin(onOk: () -> Unit) {
    val e = EditText(this)
    e.hint = "PIN"
    e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
    AlertDialog.Builder(this).setTitle("Enter PIN").setView(e)
        .setPositiveButton("OK") { _, _ ->
            if (e.text.toString() == Prefs.str(this, "pin")) onOk() else toast("Wrong PIN")
        }.setNegativeButton("Cancel", null).show()
}
