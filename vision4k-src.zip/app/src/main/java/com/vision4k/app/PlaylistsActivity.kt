package com.vision4k.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout

class PlaylistsActivity : Activity() {
    private var activated: Boolean? = null
    private var redirected = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        immersive()
        if (!intent.getBooleanExtra("pick", false) && Store.active(this) != null) {
            redirected = true
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
            return
        }
        checkPanel()
    }

    override fun onResume() {
        super.onResume()
        if (!redirected) { immersive(); build() }
    }

    private fun openHome(p: Playlist) {
        Store.setActive(this, p)
        startActivity(Intent(this, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }

    private fun options(i: Int, p: Playlist) {
        AlertDialog.Builder(this).setTitle(p.name)
            .setItems(arrayOf("Connect", "Edit", "Delete")) { _, w ->
                when (w) {
                    0 -> openHome(p)
                    1 -> startActivity(Intent(this, AddPlaylistActivity::class.java).putExtra("edit", i))
                    else -> confirmDelete(i)
                }
            }.show()
    }

    private fun playlistTile(i: Int, p: Playlist, active: Boolean): LinearLayout {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10), dp(8), dp(10), dp(8))
        t.background = round(TILE, 12)
        t.isFocusable = true
        t.isClickable = true
        t.setOnFocusChangeListener { v, f ->
            v.background = round(if (f) TILE_FOCUS else TILE, 12)
            v.scaleX = if (f) 1.04f else 1f
            v.scaleY = v.scaleX
        }
        t.setOnClickListener { openHome(p) }
        t.setOnLongClickListener { options(i, p); true }
        val ic = tv(if (active) "✔" else "▶", 24f, if (active) YELLOW else Color.WHITE)
        ic.gravity = Gravity.CENTER
        t.addView(ic)
        val nm = tv(p.name, 16f, Color.WHITE, true)
        nm.maxLines = 2
        nm.gravity = Gravity.CENTER
        nm.ellipsize = TextUtils.TruncateAt.END
        t.addView(nm)
        val ty = tv(if (p.isXtream) "Xtream Codes" else "M3U", 12f, SOFT)
        ty.gravity = Gravity.CENTER
        t.addView(ty)
        return t
    }

    private fun build() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.HORIZONTAL
        root.background = bgGradient()
        root.setPadding(dp(24), dp(16), dp(24), dp(16))

        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        head.addView(logo, lp(dp(70), dp(56)))
        head.addView(tv("   |   Playlist", 22f, SOFT))
        left.addView(head, lp(MATCH, WRAP))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val add = tile("+", "Add Playlist", 34f, 15f) { startActivity(Intent(this, AddPlaylistActivity::class.java)) }
        row.addView(add, lp(dp(160), dp(112)))
        val activeId = Store.active(this)?.id()
        val pls = Store.list(this)
        pls.forEachIndexed { i, p ->
            val lpT = lp(dp(160), dp(112))
            lpT.leftMargin = dp(10)
            row.addView(playlistTile(i, p, p.id() == activeId), lpT)
        }
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(row)
        val hp = lp(MATCH, WRAP)
        hp.topMargin = dp(16)
        left.addView(hs, hp)

        val hint = tv(if (pls.isEmpty()) "No playlist added" else "Tap to open  ·  Hold for Connect / Edit / Delete", 13f, SOFT)
        hint.setPadding(dp(2), dp(12), 0, 0)
        left.addView(hint)
        root.addView(left, lp(0, MATCH, 1.6f))

        val line = View(this)
        line.setBackgroundColor(0x66FFFFFF)
        val lpLine = lp(dp(1), MATCH)
        lpLine.leftMargin = dp(14)
        lpLine.rightMargin = dp(14)
        root.addView(line, lpLine)

        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        right.gravity = Gravity.CENTER_VERTICAL
        right.setPadding(0, dp(50), 0, 0)
        val c = PanelApi.cfg
        val status = when {
            activated == true -> "Your MAC is Activated."
            activated == false -> "Your MAC is not activated."
            c != null && c.maintenance -> "Server under maintenance"
            c != null -> "Panel connected"
            else -> "Panel not connected"
        }
        val st = tv(status, 18f, Color.WHITE, true)
        st.gravity = Gravity.CENTER
        right.addView(st)
        if (c != null && c.message.isNotEmpty()) {
            val msg = tv(c.message, 13f, SOFT)
            msg.gravity = Gravity.CENTER
            right.addView(msg)
        }
        if (PanelApi.WEB_URL.isNotBlank()) {
            val label = PanelApi.WEB_URL.removePrefix("https://").removePrefix("http://").substringBefore("#").trimEnd('/')
            val w = tv(label, 20f, YELLOW, true)
            w.gravity = Gravity.CENTER
            w.setPadding(0, dp(12), 0, dp(4))
            w.paintFlags = w.paintFlags or Paint.UNDERLINE_TEXT_FLAG
            w.isClickable = true
            w.setOnClickListener {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(PanelApi.WEB_URL))) } catch (e: Exception) { }
            }
            right.addView(w)
            val d = tv("To add/manage the playlists, use following values on website:", 14f)
            d.gravity = Gravity.CENTER
            right.addView(d)
        }
        val m1 = tv("Mac Address", 15f)
        m1.gravity = Gravity.CENTER
        m1.setPadding(0, dp(16), 0, 0)
        right.addView(m1)
        val m2 = tv(Device.mac(this), 24f, YELLOW)
        m2.gravity = Gravity.CENTER
        right.addView(m2)
        val k1 = tv("Device Key", 15f)
        k1.gravity = Gravity.CENTER
        k1.setPadding(0, dp(12), 0, 0)
        right.addView(k1)
        val k2 = tv(Device.key(this), 24f, YELLOW)
        k2.gravity = Gravity.CENTER
        right.addView(k2)
        val ver = tv("v2.3", 14f, SOFT)
        ver.gravity = Gravity.END
        ver.setPadding(0, dp(20), 0, 0)
        right.addView(ver)
        root.addView(right, lp(0, MATCH, 1f))
        setContentView(root)
    }

    private fun confirmDelete(i: Int) {
        AlertDialog.Builder(this).setTitle("Delete playlist?")
            .setPositiveButton("Delete") { _, _ -> Store.remove(this, i); build() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun checkPanel() {
        Thread {
            PanelApi.config()
            val r = PanelApi.check(Device.mac(this), Device.key(this))
            if (r != null) {
                activated = r.activated
                val u = r.playlistUrl
                if (r.activated && u != null) Store.replacePanel(this, Playlist.fromUrl("Panel", u))
            }
            runOnUiThread { if (!redirected) build() }
        }.start()
    }
}
