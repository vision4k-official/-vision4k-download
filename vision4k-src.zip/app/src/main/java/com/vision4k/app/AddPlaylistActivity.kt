package com.vision4k.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class AddPlaylistActivity : Activity() {
    private var mode = 0
    private var editIdx = -1

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        immersive()
        editIdx = intent.getIntExtra("edit", -1)
        val editing: Playlist? = if (editIdx >= 0) Store.list(this).getOrNull(editIdx) else null
        val scroll = ScrollView(this)
        scroll.background = bgGradient()
        scroll.isFillViewport = true
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(28), dp(12), dp(28), dp(16))
        scroll.addView(root)

        val head = FrameLayout(this)
        val back = tv("←", 30f)
        back.setPadding(dp(8), 0, dp(16), 0)
        back.isClickable = true
        back.isFocusable = true
        back.setOnClickListener { finish() }
        head.addView(back, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START or Gravity.CENTER_VERTICAL))
        head.addView(tv(if (editing != null) "EDIT PLAYLIST" else "ADD PLAYLIST", 22f), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        root.addView(head, lp(MATCH, WRAP))

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.gravity = Gravity.CENTER
        val tab1 = tv("ADD M3U URL", 18f, SOFT, true)
        val tab2 = tv("XTREAM-CODES-API", 18f, SOFT, true)
        for (t in listOf(tab1, tab2)) { t.setPadding(dp(20), dp(12), dp(20), dp(12)); t.isClickable = true; t.isFocusable = true }
        tabs.addView(tab1)
        tabs.addView(tab2)
        root.addView(tabs, lp(MATCH, WRAP))

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = round(0x44FFFFFF, 6)
        card.setPadding(dp(24), dp(18), dp(24), dp(18))
        val cp = lp(MATCH, WRAP); cp.topMargin = dp(8)
        root.addView(card, cp)

        val macRow = LinearLayout(this)
        macRow.orientation = LinearLayout.HORIZONTAL
        macRow.addView(tv("●  Mac Address", 17f), lp(0, WRAP, 1f))
        macRow.addView(tv(Device.mac(this), 17f))
        card.addView(macRow, lp(MATCH, WRAP))

        val name = field("name")
        val url = field("http://server_domain:8080/playlist.m3u")
        val server = field("http://server_domain:8080")
        val user = field("username")
        val pass = field("password", true)

        fun column(label: String, vararg fields: EditText): LinearLayout {
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            val lb = tv(label, 16f)
            lb.setPadding(0, dp(14), 0, dp(6))
            c.addView(lb)
            for (f in fields) c.addView(f, lp(MATCH, WRAP))
            return c
        }
        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        val cName = column("Playlist Name", name)
        val lbUrl = tv("Enter M3U", 16f)
        val cUrl = LinearLayout(this)
        cUrl.orientation = LinearLayout.VERTICAL
        lbUrl.setPadding(0, dp(14), 0, dp(6))
        cUrl.addView(lbUrl)
        cUrl.addView(url, lp(MATCH, WRAP))
        cUrl.addView(server, lp(MATCH, WRAP))
        val p1 = lp(0, WRAP, 1f); p1.rightMargin = dp(14)
        row1.addView(cName, p1)
        row1.addView(cUrl, lp(0, WRAP, 1f))
        card.addView(row1, lp(MATCH, WRAP))

        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        val p2 = lp(0, WRAP, 1f); p2.rightMargin = dp(14)
        row2.addView(column("Username", user), p2)
        row2.addView(column("Password", pass), lp(0, WRAP, 1f))
        card.addView(row2, lp(MATCH, WRAP))

        fun select(m: Int) {
            mode = m
            tab1.setTextColor(if (m == 0) Color.WHITE else SOFT)
            tab2.setTextColor(if (m == 1) Color.WHITE else SOFT)
            tab1.setBackgroundColor(if (m == 0) 0x33FFFFFF else 0)
            tab2.setBackgroundColor(if (m == 1) 0x33FFFFFF else 0)
            url.visibility = if (m == 0) View.VISIBLE else View.GONE
            server.visibility = if (m == 1) View.VISIBLE else View.GONE
            lbUrl.text = if (m == 0) "Enter M3U" else "Server URL"
            row2.visibility = if (m == 1) View.VISIBLE else View.GONE
        }
        tab1.setOnClickListener { select(0) }
        tab2.setOnClickListener { select(1) }
        select(0)
        if (editing != null) {
            name.setText(editing.name)
            if (editing.isXtream) {
                select(1)
                server.setText(editing.server)
                user.setText(editing.user)
                pass.setText(editing.pass)
            } else url.setText(editing.url)
        }

        val add = btn(if (editing != null) "SAVE" else "ADD PLAYLIST", ACCENT) {
            val n = name.text.toString().trim()
            if (mode == 0) {
                val u = url.text.toString().trim()
                if (!u.startsWith("http")) toast("Enter a valid URL (http...)")
                else finishAdd(Playlist.fromUrl(n.ifBlank { "Playlist" }, u))
            } else {
                var s = server.text.toString().trim().trimEnd('/')
                val us = user.text.toString().trim()
                val pw = pass.text.toString().trim()
                if (s.isEmpty() || us.isEmpty() || pw.isEmpty()) {
                    toast("Fill server, username and password")
                } else {
                    if (!s.startsWith("http")) s = "http://$s"
                    val p = Playlist(n.ifBlank { "Xtream" }, "xtream", "", s, us, pw)
                    toast("Checking login...")
                    Thread {
                        val ui = Xt(p).userInfo()
                        val ok = ui != null && ui.s("auth") != "0"
                        runOnUiThread { if (ok) finishAdd(p) else toast("Login failed. Check server, username and password") }
                    }.start()
                }
            }
        }
        val ap = lp(dp(260), dp(52)); ap.topMargin = dp(22); ap.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(add, ap)
        setContentView(scroll)
    }

    private fun finishAdd(p: Playlist) {
        if (editIdx >= 0) { Store.update(this, editIdx, p); toast("Saved"); finish(); return }
        Store.add(this, p)
        startActivity(Intent(this, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }
}
