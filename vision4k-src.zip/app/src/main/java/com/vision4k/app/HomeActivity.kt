package com.vision4k.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class HomeActivity : Activity() {
    private var expiry: TextView? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        immersive()
        val p = Store.active(this)
        if (p == null) {
            startActivity(Intent(this, PlaylistsActivity::class.java).putExtra("pick", true))
            finish()
            return
        }
        build()
        showExpiry()
        Thread { PanelApi.config() }.start()
    }

    override fun onResume() { super.onResume(); immersive() }

    private fun open(kind: String) {
        val c = PanelApi.cfg
        if (c != null && c.maintenance) {
            AlertDialog.Builder(this).setTitle("Maintenance")
                .setMessage(c.message.ifEmpty { "The server is under maintenance. Please try again later." })
                .setPositiveButton("OK", null).show()
            return
        }
        if (!License.valid(this)) {
            AlertDialog.Builder(this).setTitle("Activation expired")
                .setMessage("Your 1 month activation has ended. Please contact support to renew.")
                .setPositiveButton("OK", null).show()
            return
        }
        startActivity(Intent(this, ContentActivity::class.java).putExtra("type", kind))
    }

    private fun build() {
        val gap = dp(6)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = bgGradient()
        root.setPadding(dp(28), dp(10), dp(28), dp(8))

        val ex = tv("Activation valid until: ...", 14f, SOFT)
        ex.gravity = Gravity.END
        expiry = ex
        root.addView(ex, lp(MATCH, WRAP))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        root.addView(logo, lp(MATCH, 0, 1f))

        val body = LinearLayout(this)
        body.orientation = LinearLayout.HORIZONTAL

        val liveLp = lp(0, MATCH, 1.3f)
        liveLp.rightMargin = gap
        body.addView(tile("📺", "Live", 42f, 19f) { open("live") }, liveLp)

        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        val r1 = LinearLayout(this)
        r1.orientation = LinearLayout.HORIZONTAL
        val a1 = lp(0, MATCH, 1f)
        a1.rightMargin = gap
        r1.addView(tile("🎬", "Movies", 28f, 15f) { open("movies") }, a1)
        r1.addView(tile("🎞", "Series", 28f, 15f) { open("series") }, lp(0, MATCH, 1f))
        val r2 = LinearLayout(this)
        r2.orientation = LinearLayout.HORIZONTAL
        val a2 = lp(0, MATCH, 1f)
        a2.rightMargin = gap
        r2.addView(tile("👤", "Account", 28f, 15f) { account() }, a2)
        r2.addView(tile("🎵", "Playlists", 28f, 15f) {
            startActivity(Intent(this, PlaylistsActivity::class.java).putExtra("pick", true))
        }, lp(0, MATCH, 1f))
        val m1 = lp(MATCH, 0, 1f)
        m1.bottomMargin = gap
        mid.addView(r1, m1)
        mid.addView(r2, lp(MATCH, 0, 1f))
        val midLp = lp(0, MATCH, 2f)
        midLp.rightMargin = gap
        body.addView(mid, midLp)

        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        val b1 = lp(MATCH, 0, 1f)
        b1.bottomMargin = gap
        right.addView(tile("⚙", "Settings", 20f, 15f, true) { startActivity(Intent(this, SettingsActivity::class.java)) }, b1)
        val b2 = lp(MATCH, 0, 1f)
        b2.bottomMargin = gap
        right.addView(tile("⟳", "Reload", 20f, 15f, true) { reload() }, b2)
        right.addView(tile("✖", "EXIT", 20f, 15f, true) { finishAffinity() }, lp(MATCH, 0, 1f))
        body.addView(right, lp(0, MATCH, 1.2f))

        val bw = minOf((resources.displayMetrics.widthPixels * 0.6).toInt(), dp(520))
        val bl = lp(bw, dp(176))
        bl.gravity = Gravity.CENTER_HORIZONTAL
        bl.topMargin = dp(4)
        root.addView(body, bl)

        val ver = tv("v2.3", 13f, SOFT)
        ver.gravity = Gravity.END
        root.addView(ver, lp(MATCH, WRAP))
        setContentView(root)
    }

    private fun showExpiry() {
        expiry?.text = "Activation valid until: ${fmtDate(License.expiry(this))}"
    }

    private fun reload() {
        toast("Reloading...")
        Thread {
            PanelApi.config()
            val r = PanelApi.check(Device.mac(this), Device.key(this))
            val u = r?.playlistUrl
            if (r != null && r.activated && u != null) Store.replacePanel(this, Playlist.fromUrl("Panel", u))
            Repo.clear()
            runOnUiThread { toast("Reloaded") }
        }.start()
    }

    private fun account() {
        val p = Store.active(this) ?: return
        Thread {
            val ui = if (p.isXtream) Xt(p).userInfo() else null
            runOnUiThread {
                val sb = StringBuilder()
                sb.append("Playlist: ${p.name}\n")
                sb.append("Type: ${if (p.isXtream) "Xtream Codes" else "M3U"}\n")
                sb.append("Activation until: ${fmtDate(License.expiry(this))}\n")
                if (p.isXtream) {
                    sb.append("Server: ${p.server}\nUsername: ${p.user}\n")
                    if (ui != null) {
                        sb.append("Status: ${ui.s("status")}\nPlaylist expires: ${expText(ui)}\n")
                        sb.append("Max connections: ${ui.s("max_connections")}\nActive connections: ${ui.s("active_cons")}\n")
                    }
                }
                sb.append("MAC: ${Device.mac(this)}")
                AlertDialog.Builder(this).setTitle("Account").setMessage(sb.toString()).setPositiveButton("OK", null).show()
            }
        }.start()
    }
}
