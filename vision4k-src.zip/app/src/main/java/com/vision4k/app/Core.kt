package com.vision4k.app

import android.content.Context
import android.net.Uri
import android.provider.Settings
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun JSONObject.s(k: String): String {
    val v = opt(k)
    return if (v == null || v == JSONObject.NULL) "" else v.toString()
}

fun fmtDate(ms: Long): String = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(ms))

fun fmtTime(c: Context, ms: Long): String =
    SimpleDateFormat(if (Prefs.bool(c, "h24", true)) "HH:mm" else "hh:mm a", Locale.getDefault()).format(Date(ms))

fun expText(ui: JSONObject?): String {
    val ts = ui?.s("exp_date")?.toLongOrNull()
    return if (ts != null && ts > 0) fmtDate(ts * 1000) else "unlimited"
}

object Device {
    private fun hash(c: Context): ByteArray {
        val a = Settings.Secure.getString(c.contentResolver, Settings.Secure.ANDROID_ID) ?: "0"
        return MessageDigest.getInstance("SHA-256").digest(("v4k-$a").toByteArray())
    }
    fun mac(c: Context): String {
        val h = hash(c)
        return "00:1A:79:%02X:%02X:%02X".format(h[0], h[1], h[2])
    }
    fun key(c: Context): String {
        val h = hash(c)
        val x = (h[0].toInt() and 0xFF) xor (h[1].toInt() and 0xFF) xor (h[2].toInt() and 0xFF) xor 0x50
        return "AP4K-%02X%02X%02X%02X".format(h[0], h[1], h[2], x)
    }
}

object License {
    private const val PERIOD = 30L * 24 * 60 * 60 * 1000
    fun start(c: Context): Long {
        var s = Prefs.str(c, "first_run").toLongOrNull() ?: 0L
        if (s == 0L) { s = System.currentTimeMillis(); Prefs.setStr(c, "first_run", s.toString()) }
        return s
    }
    fun expiry(c: Context): Long = start(c) + PERIOD
    fun valid(c: Context): Boolean = System.currentTimeMillis() < expiry(c)
}

data class Media(val title: String, val url: String, val icon: String, val sid: String, val live: Boolean)

object Queue {
    var list: List<Media> = emptyList()
    var idx: Int = 0
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("v4k_prefs2", Context.MODE_PRIVATE)
    fun int(c: Context, k: String, d: Int = 0): Int = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) { sp(c).edit().putInt(k, v).apply() }
    fun bool(c: Context, k: String, d: Boolean = false): Boolean = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
    fun str(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun setStr(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }
    fun getSet(c: Context, k: String): MutableSet<String> = HashSet(sp(c).getStringSet(k, emptySet()) ?: emptySet())
    fun putSet(c: Context, k: String, v: Set<String>) { sp(c).edit().putStringSet(k, HashSet(v)).apply() }

    fun toggleFav(c: Context, key: String): Boolean {
        val s = getSet(c, "fav")
        val added = if (s.contains(key)) { s.remove(key); false } else { s.add(key); true }
        putSet(c, "fav", s)
        return added
    }
    fun recent(c: Context, type: String): List<String> {
        val s = str(c, "recent_$type")
        return if (s.isEmpty()) emptyList() else s.split("\n")
    }
    fun pushRecent(c: Context, type: String, key: String) {
        val l = recent(c, type).toMutableList()
        l.remove(key); l.add(0, key)
        while (l.size > 50) l.removeAt(l.size - 1)
        setStr(c, "recent_$type", l.joinToString("\n"))
    }
    fun clearRecent(c: Context, type: String) { setStr(c, "recent_$type", "") }
}

data class Playlist(
    val name: String, val type: String, val url: String = "",
    val server: String = "", val user: String = "", val pass: String = ""
) {
    val isXtream: Boolean get() = type == "xtream"
    fun id(): String = if (isXtream) "$server|$user" else url
    fun toJson(): JSONObject = JSONObject().put("n", name).put("t", type).put("u", url)
        .put("s", server).put("us", user).put("p", pass)

    companion object {
        fun fromJson(o: JSONObject) = Playlist(o.s("n"), o.s("t").ifEmpty { "m3u" }, o.s("u"), o.s("s"), o.s("us"), o.s("p"))
        fun fromUrl(name: String, url: String): Playlist {
            val m = Regex("^(https?://[^/]+)/(?:get|player_api)\\.php\\?(.*)$").find(url)
            if (m != null) {
                val q = m.groupValues[2]
                val u = Regex("(?:^|&)username=([^&]*)").find(q)?.groupValues?.get(1)
                val p = Regex("(?:^|&)password=([^&]*)").find(q)?.groupValues?.get(1)
                if (u != null && p != null) return Playlist(name, "xtream", "", m.groupValues[1], Uri.decode(u), Uri.decode(p))
            }
            return Playlist(name, "m3u", url)
        }
    }
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("v4k2", Context.MODE_PRIVATE)
    fun list(c: Context): MutableList<Playlist> {
        val arr = try { JSONArray(sp(c).getString("pl", "[]")) } catch (e: Exception) { JSONArray() }
        return MutableList(arr.length()) { Playlist.fromJson(arr.getJSONObject(it)) }
    }
    fun save(c: Context, l: List<Playlist>) {
        val arr = JSONArray()
        l.forEach { arr.put(it.toJson()) }
        sp(c).edit().putString("pl", arr.toString()).apply()
    }
    fun add(c: Context, p: Playlist) {
        val l = list(c).filter { it.id() != p.id() }.toMutableList()
        l.add(p); save(c, l); setActive(c, p)
    }
    fun remove(c: Context, i: Int) {
        val l = list(c)
        if (i in l.indices) {
            val gone = l.removeAt(i)
            save(c, l)
            if (sp(c).getString("active", "") == gone.id()) sp(c).edit().remove("active").apply()
            Repo.clear()
        }
    }
    fun active(c: Context): Playlist? {
        val id = sp(c).getString("active", "") ?: ""
        return list(c).firstOrNull { it.id() == id }
    }
    fun setActive(c: Context, p: Playlist) {
        sp(c).edit().putString("active", p.id()).apply()
        Repo.clear()
    }
    fun update(c: Context, i: Int, p: Playlist) {
        val l = list(c)
        if (i !in l.indices) return
        val oldId = l[i].id()
        val wasActive = (sp(c).getString("active", "") ?: "") == oldId
        l[i] = p
        save(c, l)
        if (wasActive) setActive(c, p) else Repo.clear()
    }
    fun replacePanel(c: Context, p: Playlist) {
        val l = list(c).filter { it.name != "Panel" }.toMutableList()
        l.add(0, p); save(c, l)
        if (active(c) == null) setActive(c, p)
    }
}

data class Cfg(val appName: String, val maintenance: Boolean, val message: String, val latest: String)

object PanelApi {
    const val HOST = "https://albplayr.openibc.fit"
    const val BASE_URL = ""   // endpoint i aktivizimit, vendoset kur te dihet formati
    const val WEB_URL = "https://vision4k-official.github.io/add/#home"

    @Volatile var cfg: Cfg? = null

    data class Result(val activated: Boolean, val playlistUrl: String?)

    fun config(): Cfg? = try {
        val o = JSONObject(Net.get("$HOST/api/config.php", 10000))
        if (!o.optBoolean("success", false)) null
        else {
            val c = Cfg(o.s("app_name"), o.optBoolean("maintenance", false), o.s("message"), o.s("latest_version"))
            cfg = c
            c
        }
    } catch (e: Exception) { null }

    fun check(mac: String, key: String): Result? {
        if (BASE_URL.isBlank()) return null
        return try {
            val o = JSONObject(Net.get("$BASE_URL/activate?mac=$mac&key=$key", 10000))
            Result(o.optBoolean("activated", false), o.s("playlist_url").ifBlank { null })
        } catch (e: Exception) { null }
    }

    private fun post(url: String, data: String): String {
        val con = URL(url).openConnection() as HttpURLConnection
        con.requestMethod = "POST"
        con.doOutput = true
        con.connectTimeout = 7000
        con.readTimeout = 7000
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        con.setRequestProperty("User-Agent", "Vision4K/2.3")
        con.outputStream.use { it.write(("data=" + Uri.encode(data)).toByteArray()) }
        val code = con.responseCode
        val st = if (code >= 400) con.errorStream else con.inputStream
        return st?.bufferedReader()?.use { it.readText() } ?: "HTTP $code"
    }

    private fun decode(raw: String): String = try {
        val d = JSONObject(raw).s("data")
        if (d.isEmpty()) raw else {
            try { String(Base64.decode(d.dropLast(2), Base64.DEFAULT), Charsets.UTF_8) } catch (e: Exception) { d }
        }
    } catch (e: Exception) { raw }

    /** Teston lidhjen me panelin dhe tregon pergjigjet e serverit (per te zbuluar formatin e kerkeses). */
    fun diagnose(c: Context): String {
        val mac = Device.mac(c)
        val key = Device.key(c)
        val sb = StringBuilder()
        sb.append("MAC: $mac\nKey: $key\n\n")
        sb.append("config.php:\n")
        sb.append(try { Net.get("$HOST/api/config.php", 8000).take(300) } catch (e: Exception) { "ERROR ${e.message}" })
        sb.append("\n\n")
        val payloads = listOf(
            "A" to "{\"mac\":\"$mac\",\"key\":\"$key\"}",
            "B" to "{\"mac_address\":\"$mac\",\"device_key\":\"$key\"}",
            "C" to "{\"device_id\":\"$mac\",\"device_key\":\"$key\"}"
        )
        for (ep in listOf("app/api/api.php", "app/api/playlist.php")) {
            sb.append(ep).append(":\n")
            for ((n, json) in payloads) {
                val b64 = Base64.encodeToString(json.toByteArray(), Base64.NO_WRAP)
                for ((tag, data) in listOf("$n b64" to b64, "$n b64+aa" to b64 + "aa")) {
                    val r = try { decode(post("$HOST/$ep", data)) } catch (e: Exception) { "ERROR ${e.message}" }
                    sb.append(" [$tag] ").append(r.take(160)).append("\n")
                }
            }
            val r = try { decode(post("$HOST/$ep", payloads[0].second)) } catch (e: Exception) { "ERROR ${e.message}" }
            sb.append(" [A plain] ").append(r.take(160)).append("\n\n")
        }
        return sb.toString()
    }
}

data class Cat(val id: String, val name: String)
data class Item(
    val key: String, val id: String, val name: String, val cat: String, val icon: String,
    val url: String, val type: String, val num: Int, val info: String = "", val ext: String = ""
)
data class Epg(val start: Long, val end: Long, val title: String)
data class Ep(val label: String, val id: String, val ext: String)

class Xt(private val p: Playlist) {
    private fun base() = "${p.server}/player_api.php?username=${Uri.encode(p.user)}&password=${Uri.encode(p.pass)}"

    fun userInfo(): JSONObject? = try {
        JSONObject(Net.get(base(), 20000)).optJSONObject("user_info")
    } catch (e: Exception) { null }

    private fun arr(action: String): JSONArray = try {
        JSONArray(Net.get("${base()}&action=$action"))
    } catch (e: Exception) { JSONArray() }

    fun cats(kind: String): List<Cat> {
        val a = arr(when (kind) { "live" -> "get_live_categories"; "movies" -> "get_vod_categories"; else -> "get_series_categories" })
        val out = ArrayList<Cat>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            out.add(Cat(o.s("category_id"), o.s("category_name")))
        }
        return out
    }

    fun items(kind: String): List<Item> {
        val a = arr(when (kind) { "live" -> "get_live_streams"; "movies" -> "get_vod_streams"; else -> "get_series" })
        val out = ArrayList<Item>(a.length())
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            when (kind) {
                "live" -> out.add(Item("live:" + o.s("stream_id"), o.s("stream_id"), o.s("name"), o.s("category_id"),
                    o.s("stream_icon"), "", "live", o.s("num").toIntOrNull() ?: (i + 1)))
                "movies" -> {
                    val r = o.s("rating")
                    out.add(Item("movies:" + o.s("stream_id"), o.s("stream_id"), o.s("name"), o.s("category_id"),
                        o.s("stream_icon"), "", "movies", i + 1, if (r.isNotEmpty() && r != "0") "Rating: $r" else "", o.s("container_extension")))
                }
                else -> out.add(Item("series:" + o.s("series_id"), o.s("series_id"), o.s("name"), o.s("category_id"),
                    o.s("cover"), "", "series", i + 1, o.s("plot"), ""))
            }
        }
        return out
    }

    private fun dec(s: String): String = try {
        String(Base64.decode(s, Base64.DEFAULT), Charsets.UTF_8)
    } catch (e: Exception) { s }

    fun epg(streamId: String): List<Epg> = try {
        val o = JSONObject(Net.get("${base()}&action=get_short_epg&stream_id=$streamId&limit=5", 15000))
        val l = o.optJSONArray("epg_listings") ?: JSONArray()
        val out = ArrayList<Epg>()
        for (i in 0 until l.length()) {
            val e = l.optJSONObject(i) ?: continue
            out.add(Epg((e.s("start_timestamp").toLongOrNull() ?: 0L) * 1000, (e.s("stop_timestamp").toLongOrNull() ?: 0L) * 1000, dec(e.s("title"))))
        }
        out
    } catch (e: Exception) { emptyList() }

    fun episodes(seriesId: String): List<Ep> {
        val out = ArrayList<Ep>()
        try {
            val o = JSONObject(Net.get("${base()}&action=get_series_info&series_id=$seriesId"))
            val e = o.opt("episodes")
            fun addSeason(season: String, arr: JSONArray?) {
                if (arr == null) return
                for (i in 0 until arr.length()) {
                    val ep = arr.optJSONObject(i) ?: continue
                    out.add(Ep("S$season E${ep.s("episode_num")}  ${ep.s("title")}", ep.s("id"), ep.s("container_extension").ifEmpty { "mp4" }))
                }
            }
            if (e is JSONObject) {
                val keys = ArrayList<String>()
                val iter = e.keys()
                while (iter.hasNext()) keys.add(iter.next())
                keys.sortedBy { k -> k.toIntOrNull() ?: 0 }.forEach { k -> addSeason(k, e.optJSONArray(k)) }
            } else if (e is JSONArray) {
                for (i in 0 until e.length()) addSeason((i + 1).toString(), e.optJSONArray(i))
            }
        } catch (ex: Exception) { }
        return out
    }

    companion object {
        fun episodeUrl(p: Playlist, id: String, ext: String) = "${p.server}/series/${p.user}/${p.pass}/$id.$ext"
    }
}

object Repo {
    private var key = ""
    private val cats = HashMap<String, List<Cat>>()
    private val items = HashMap<String, List<Item>>()

    @Synchronized fun clear() { cats.clear(); items.clear(); key = "" }

    @Synchronized fun get(p: Playlist, kind: String): Pair<List<Cat>, List<Item>> {
        if (key != p.id()) { cats.clear(); items.clear(); key = p.id() }
        val c = cats[kind]
        val i = items[kind]
        if (c != null && i != null) return Pair(c, i)
        if (p.isXtream) {
            val x = Xt(p)
            cats[kind] = x.cats(kind)
            items[kind] = x.items(kind)
        } else {
            val all = M3u.parse(p.url)
            for (k in listOf("live", "movies", "series")) {
                val l = all.filter { it.type == k }
                items[k] = l
                cats[k] = l.map { it.cat }.distinct().map { Cat(it, it) }
            }
        }
        return Pair(cats[kind] ?: emptyList(), items[kind] ?: emptyList())
    }

    fun playUrl(c: Context, p: Playlist, item: Item): String {
        if (item.url.isNotEmpty()) return item.url
        return if (item.type == "live") "${p.server}/live/${p.user}/${p.pass}/${item.id}.${Prefs.str(c, "fmt", "ts")}"
        else "${p.server}/movie/${p.user}/${p.pass}/${item.id}.${item.ext.ifEmpty { "mp4" }}"
    }
}
