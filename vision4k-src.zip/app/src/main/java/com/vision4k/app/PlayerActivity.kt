package com.vision4k.app

import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var pv: PlayerView
    private lateinit var overlay: FrameLayout
    private lateinit var spinner: ProgressBar
    private lateinit var titleTv: TextView
    private lateinit var infoTv: TextView
    private lateinit var picon: ImageView
    private lateinit var epgNow: TextView
    private lateinit var epgNext: TextView
    private lateinit var playBtn: TextView
    private lateinit var seekRow: LinearLayout
    private lateinit var seek: SeekBar
    private lateinit var posTv: TextView
    private lateinit var durTv: TextView
    private lateinit var prevBtn: TextView
    private lateinit var nextBtn: TextView
    private lateinit var rewBtn: TextView
    private lateinit var fwdBtn: TextView
    private lateinit var aspectBtn: TextView
    private var dragging = false

    private val hideRun = Runnable { overlay.visibility = View.GONE }

    private val tick = object : Runnable {
        override fun run() {
            val p = player
            val m = Queue.list.getOrNull(Queue.idx)
            if (p != null && m != null && !m.live && !dragging) {
                val d = p.duration
                if (d > 0 && d != C.TIME_UNSET) {
                    seek.max = (d / 1000).toInt()
                    seek.progress = (p.currentPosition / 1000).toInt()
                    posTv.text = hms(p.currentPosition)
                    durTv.text = hms(d)
                }
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        immersive()
        if (Queue.list.isEmpty()) { finish(); return }

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        pv = PlayerView(this)
        pv.useController = false
        pv.resizeMode = aspectMode()
        pv.setOnClickListener { toggleOverlay() }
        root.addView(pv, FrameLayout.LayoutParams(MATCH, MATCH))
        spinner = ProgressBar(this)
        root.addView(spinner, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))
        overlay = buildOverlay()
        root.addView(overlay, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)

        val p = ExoPlayer.Builder(this).build()
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                spinner.visibility = if (playbackState == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
                updateInfo()
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playBtn.text = if (isPlaying) "⏸" else "▶"
            }
            override fun onVideoSizeChanged(videoSize: VideoSize) { updateInfo() }
            override fun onTracksChanged(tracks: Tracks) { updateInfo() }
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@PlayerActivity, "Cannot play this stream", Toast.LENGTH_SHORT).show()
                showOverlay()
            }
        })
        pv.player = p
        player = p
        start(Queue.idx)
        handler.post(tick)
        showOverlay()
    }

    private fun aspectMode(): Int = when (Prefs.int(this, "aspect")) { 1 -> 3; 2 -> 4; else -> 0 }
    private fun aspectLabel(): String = arrayOf("Fit", "Fill", "Zoom")[Prefs.int(this, "aspect").coerceIn(0, 2)]

    private fun cycleAspect() {
        val n = (Prefs.int(this, "aspect") + 1) % 3
        Prefs.setInt(this, "aspect", n)
        pv.resizeMode = aspectMode()
        aspectBtn.text = "⛶ ${aspectLabel()}"
    }

    private fun pill(label: String, onClick: () -> Unit): TextView {
        val t = tv(label, 14f)
        t.setPadding(dp(14), dp(8), dp(14), dp(8))
        t.background = round(0x66303A4C, 18)
        t.isFocusable = true
        t.isClickable = true
        t.setOnClickListener { onClick(); showOverlay() }
        t.setOnFocusChangeListener { v, f -> v.alpha = if (f) 1f else 0.85f }
        val p = LinearLayout.LayoutParams(WRAP, WRAP)
        p.leftMargin = dp(8)
        t.layoutParams = p
        return t
    }

    private fun ctl(sym: String, size: Int, big: Boolean, onClick: () -> Unit): TextView {
        val t = tv(sym, if (big) 26f else 20f)
        t.gravity = Gravity.CENTER
        t.background = round(if (big) ACCENT else 0x66303A4C, size / 2)
        t.isFocusable = true
        t.isClickable = true
        t.setOnClickListener { onClick(); showOverlay() }
        t.setOnFocusChangeListener { v, f -> v.scaleX = if (f) 1.12f else 1f; v.scaleY = v.scaleX }
        val p = LinearLayout.LayoutParams(dp(size), dp(size))
        p.leftMargin = dp(8)
        p.rightMargin = dp(8)
        t.layoutParams = p
        return t
    }

    private fun buildOverlay(): FrameLayout {
        val o = FrameLayout(this)

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(16), dp(10), dp(16), dp(26))
        top.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCC000000.toInt(), 0x00000000))
        val back = tv("←", 28f)
        back.setPadding(dp(6), 0, dp(14), 0)
        back.isClickable = true
        back.isFocusable = true
        back.setOnClickListener { finish() }
        top.addView(back)
        picon = ImageView(this)
        picon.scaleType = ImageView.ScaleType.FIT_CENTER
        val pp = lp(dp(54), dp(40))
        pp.rightMargin = dp(12)
        top.addView(picon, pp)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        titleTv = tv("", 20f, Color.WHITE, true)
        titleTv.maxLines = 1
        titleTv.ellipsize = TextUtils.TruncateAt.END
        infoTv = tv("", 13f, SOFT)
        infoTv.maxLines = 1
        col.addView(titleTv)
        col.addView(infoTv)
        top.addView(col, lp(0, WRAP, 1f))
        aspectBtn = pill("⛶ ${aspectLabel()}") { cycleAspect() }
        top.addView(aspectBtn)
        top.addView(pill("🔊 Audio / Subs") { tracksDialog() })
        o.addView(top, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        bottom.setPadding(dp(24), dp(34), dp(24), dp(14))
        bottom.background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xDD000000.toInt(), 0x00000000))
        epgNow = tv("", 15f, YELLOW)
        epgNow.maxLines = 1
        epgNext = tv("", 13f, SOFT)
        epgNext.maxLines = 1
        bottom.addView(epgNow)
        bottom.addView(epgNext)

        seekRow = LinearLayout(this)
        seekRow.orientation = LinearLayout.HORIZONTAL
        seekRow.gravity = Gravity.CENTER_VERTICAL
        posTv = tv("00:00", 13f)
        durTv = tv("00:00", 13f)
        seek = SeekBar(this)
        seek.progressTintList = ColorStateList.valueOf(ACCENT)
        seek.thumbTintList = ColorStateList.valueOf(ACCENT)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) posTv.text = hms(progress * 1000L)
            }
            override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar?) {
                player?.seekTo((s?.progress ?: 0) * 1000L)
                dragging = false
                showOverlay()
            }
        })
        seekRow.addView(posTv)
        seekRow.addView(seek, lp(0, WRAP, 1f))
        seekRow.addView(durTv)
        bottom.addView(seekRow, lp(MATCH, WRAP))

        val controls = LinearLayout(this)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        prevBtn = ctl("⏮", 46, false) { go(-1) }
        rewBtn = ctl("⏪", 46, false) { player?.let { it.seekTo(maxOf(0L, it.currentPosition - 10000L)) } }
        playBtn = ctl("⏸", 60, true) { togglePlay() }
        fwdBtn = ctl("⏩", 46, false) { player?.let { it.seekTo(it.currentPosition + 10000L) } }
        nextBtn = ctl("⏭", 46, false) { go(1) }
        controls.addView(prevBtn)
        controls.addView(rewBtn)
        controls.addView(playBtn)
        controls.addView(fwdBtn)
        controls.addView(nextBtn)
        val cp = lp(MATCH, WRAP)
        cp.topMargin = dp(6)
        bottom.addView(controls, cp)
        o.addView(bottom, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        return o
    }

    private fun start(i: Int) {
        val q = Queue.list
        if (i !in q.indices) return
        Queue.idx = i
        val m = q[i]
        titleTv.text = m.title
        Img.load(m.icon, picon)
        infoTv.text = ""
        epgNow.text = ""
        epgNext.text = ""
        val p = player ?: return
        p.setMediaItem(MediaItem.fromUri(m.url))
        p.prepare()
        p.playWhenReady = true
        updateNav()
        loadEpg(m)
    }

    private fun updateNav() {
        val m = Queue.list[Queue.idx]
        val multi = Queue.list.size > 1
        prevBtn.visibility = if (multi) View.VISIBLE else View.GONE
        nextBtn.visibility = if (multi) View.VISIBLE else View.GONE
        rewBtn.visibility = if (m.live) View.GONE else View.VISIBLE
        fwdBtn.visibility = if (m.live) View.GONE else View.VISIBLE
        seekRow.visibility = if (m.live) View.GONE else View.VISIBLE
        epgNow.visibility = if (m.live) View.VISIBLE else View.GONE
        epgNext.visibility = if (m.live) View.VISIBLE else View.GONE
    }

    private fun go(d: Int) {
        val n = Queue.idx + d
        if (n in Queue.list.indices) start(n)
    }

    private fun togglePlay() {
        val p = player ?: return
        if (p.isPlaying) p.pause() else p.play()
    }

    private fun loadEpg(m: Media) {
        val pl = Store.active(this)
        if (!m.live || pl == null || !pl.isXtream || m.sid.isEmpty()) return
        Thread {
            val e = Xt(pl).epg(m.sid)
            runOnUiThread {
                if (Queue.list.getOrNull(Queue.idx)?.sid == m.sid) {
                    if (e.isNotEmpty()) epgNow.text = "NOW  ${fmtTime(this, e[0].start)} ~ ${fmtTime(this, e[0].end)}   ${e[0].title}"
                    if (e.size > 1) epgNext.text = "NEXT  ${fmtTime(this, e[1].start)}   ${e[1].title}"
                }
            }
        }.start()
    }

    private fun codec(m: String?): String? = when {
        m == null -> null
        m.contains("avc") -> "H.264"
        m.contains("hevc") -> "H.265"
        m.contains("av01") -> "AV1"
        m.contains("vp9") -> "VP9"
        m.contains("mpeg2") -> "MPEG-2"
        m.contains("mp4a") -> "AAC"
        m.contains("eac3") -> "E-AC3"
        m.contains("ac3") -> "AC3"
        m.contains("mpeg") -> "MP3"
        else -> null
    }

    private fun updateInfo() {
        val p = player ?: return
        val parts = ArrayList<String>()
        val vs = p.videoSize
        if (vs.height > 0) {
            val q = when {
                vs.height >= 2000 -> "4K"
                vs.height >= 1000 -> "FHD"
                vs.height >= 700 -> "HD"
                else -> "SD"
            }
            parts.add("${vs.width}x${vs.height}")
            parts.add(q)
        }
        for (g in p.currentTracks.groups) {
            if (g.type == C.TRACK_TYPE_VIDEO) {
                for (i in 0 until g.length) {
                    if (g.isTrackSelected(i)) {
                        val f = g.getTrackFormat(i)
                        if (f.frameRate > 0) parts.add("${Math.round(f.frameRate)} fps")
                        codec(f.sampleMimeType)?.let { parts.add(it) }
                        if (f.bitrate > 0) parts.add("%.1f Mbps".format(f.bitrate / 1000000.0))
                    }
                }
            } else if (g.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until g.length) {
                    if (g.isTrackSelected(i)) {
                        val f = g.getTrackFormat(i)
                        val c = codec(f.sampleMimeType)
                        val ch = when (f.channelCount) { 1 -> "Mono"; 2 -> "Stereo"; 6 -> "5.1"; 8 -> "7.1"; else -> "" }
                        val label = listOfNotNull(c, ch.ifEmpty { null }).joinToString(" ")
                        if (label.isNotEmpty()) parts.add(label)
                    }
                }
            }
        }
        infoTv.text = parts.joinToString("  ·  ")
    }

    private fun tracksDialog() {
        val p = player ?: return
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        for (g in p.currentTracks.groups) {
            if (g.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until g.length) {
                    val f = g.getTrackFormat(i)
                    val nm = f.label ?: f.language ?: "Track ${labels.size + 1}"
                    labels.add("Audio: $nm" + (if (g.isTrackSelected(i)) "  ✓" else ""))
                    actions.add {
                        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build()
                    }
                }
            }
        }
        for (g in p.currentTracks.groups) {
            if (g.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until g.length) {
                    val f = g.getTrackFormat(i)
                    val nm = f.label ?: f.language ?: "Track ${labels.size + 1}"
                    labels.add("Subtitle: $nm" + (if (g.isTrackSelected(i)) "  ✓" else ""))
                    actions.add {
                        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build()
                    }
                }
            }
        }
        labels.add("Subtitles: Off")
        actions.add {
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
        }
        AlertDialog.Builder(this).setTitle("Audio / Subtitles")
            .setItems(labels.toTypedArray()) { _, i -> actions[i]() }.show()
    }

    private fun hms(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
    }

    private fun showOverlay() {
        overlay.visibility = View.VISIBLE
        handler.removeCallbacks(hideRun)
        handler.postDelayed(hideRun, 5000)
    }

    private fun toggleOverlay() {
        if (overlay.visibility == View.VISIBLE) {
            handler.removeCallbacks(hideRun)
            overlay.visibility = View.GONE
        } else showOverlay()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val live = Queue.list.getOrNull(Queue.idx)?.live == true
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (overlay.visibility != View.VISIBLE) { showOverlay(); return true }
            }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePlay(); return true }
            KeyEvent.KEYCODE_CHANNEL_UP -> { go(1); return true }
            KeyEvent.KEYCODE_CHANNEL_DOWN -> { go(-1); return true }
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (live && overlay.visibility != View.VISIBLE) { go(1); return true }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (live && overlay.visibility != View.VISIBLE) { go(-1); return true }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        finish()
    }
}
