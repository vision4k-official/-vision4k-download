package com.vision4k.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class Opt(val icon: String, val label: String, val run: () -> Unit)

class SettingsActivity : Activity() {

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        immersive()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = bgGradient()
        root.setPadding(dp(24), dp(10), dp(24), dp(10))

        val head = FrameLayout(this)
        val back = tv("←", 30f)
        back.setPadding(dp(8), 0, dp(16), 0)
        back.isClickable = true
        back.isFocusable = true
        back.setOnClickListener { finish() }
        head.addView(back, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START or Gravity.CENTER_VERTICAL))
        head.addView(tv("Settings", 24f), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        root.addView(head, lp(MATCH, WRAP))

        val opts = listOf(
            Opt("➕", "Add Playlist") { startActivity(Intent(this, AddPlaylistActivity::class.java)) },
            Opt("🔒", "Parental Control") { parental() },
            Opt("📋", "Change Playlist") { startActivity(Intent(this, PlaylistsActivity::class.java).putExtra("pick", true)) },
            Opt("🔠", "Change Layout") {
                choice("Text size", arrayOf("Small", "Medium", "Large"), Prefs.int(this, "text", 1)) { Prefs.setInt(this, "text", it) }
            },
            Opt("🚫", "Hide Live Categories") { hideCats("live", "Hide Live Categories") },
            Opt("🚫", "Hide Vod Categories") { hideCats("movies", "Hide Vod Categories") },
            Opt("🚫", "Hide Series Categories") { hideCats("series", "Hide Series Categories") },
            Opt("🗑", "Clear History Movies") { Prefs.clearRecent(this, "movies"); toast("History cleared") },
            Opt("🗑", "Clear History Series") { Prefs.clearRecent(this, "series"); toast("History cleared") },
            Opt("📡", "Live Stream Format") {
                choice("Live stream format", arrayOf("TS", "M3U8"), if (Prefs.str(this, "fmt", "ts") == "m3u8") 1 else 0) {
                    Prefs.setStr(this, "fmt", if (it == 1) "m3u8" else "ts")
                }
            },
            Opt("▶", "External players") {
                choice("Player", arrayOf("Built-in player", "External player"), if (Prefs.bool(this, "ext")) 1 else 0) {
                    Prefs.setBool(this, "ext", it == 1)
                }
            },
            Opt("✨", "Auto Play") {
                choice("Auto play last channel", arrayOf("Off", "On"), if (Prefs.bool(this, "auto")) 1 else 0) {
                    Prefs.setBool(this, "auto", it == 1)
                }
            },
            Opt("🕒", "Time Format") {
                choice("Time format", arrayOf("12 hour", "24 hour"), if (Prefs.bool(this, "h24", true)) 1 else 0) {
                    Prefs.setBool(this, "h24", it == 1)
                }
            },
            Opt("🖥", "Aspect Ratio") {
                choice("Aspect ratio", arrayOf("Fit", "Fill", "Zoom"), Prefs.int(this, "aspect")) { Prefs.setInt(this, "aspect", it) }
            },
            Opt("🌐", "Panel Test") { panelTest() }
        )

        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        for (chunk in opts.chunked(4)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (i in 0 until 4) {
                val cp = lp(0, dp(64), 1f)
                cp.setMargins(dp(5), dp(5), dp(5), dp(5))
                if (i < chunk.size) {
                    val o = chunk[i]
                    row.addView(tile(o.icon, o.label, 22f, 15f, true) { o.run() }, cp)
                } else row.addView(View(this), cp)
            }
            grid.addView(row, lp(MATCH, WRAP))
        }
        val sv = ScrollView(this)
        sv.addView(grid)
        val sp = lp(MATCH, 0, 1f); sp.topMargin = dp(8)
        root.addView(sv, sp)

        val mac = tv("Mac Address: ${Device.mac(this)}", 22f, android.graphics.Color.WHITE, true)
        mac.gravity = Gravity.CENTER
        mac.setPadding(0, dp(6), 0, dp(6))
        root.addView(mac, lp(MATCH, WRAP))
        setContentView(root)
    }

    private fun panelTest() {
        toast("Testing panel...")
        Thread {
            val out = PanelApi.diagnose(this)
            runOnUiThread {
                val t = TextView(this)
                t.text = out
                t.textSize = 12f
                t.setTextIsSelectable(true)
                t.setPadding(dp(16), dp(8), dp(16), dp(8))
                val sv = ScrollView(this)
                sv.addView(t)
                AlertDialog.Builder(this).setTitle("Panel test").setView(sv).setPositiveButton("OK", null).show()
            }
        }.start()
    }

    private fun choice(title: String, opts: Array<String>, cur: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(title)
            .setSingleChoiceItems(opts, cur) { d, w -> onPick(w); d.dismiss() }.show()
    }

    private fun parental() {
        val pin = Prefs.str(this, "pin")
        if (pin.isEmpty()) { newPin(); return }
        askPin {
            choice("Parental Control", arrayOf("Change PIN", "Remove PIN"), -1) {
                if (it == 0) newPin() else { Prefs.setStr(this, "pin", ""); toast("PIN removed") }
            }
        }
    }

    private fun newPin() {
        val e = EditText(this)
        e.hint = "New 4-digit PIN"
        e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        AlertDialog.Builder(this).setTitle("Set PIN").setMessage("Adult categories (xxx, adult, 18+) will ask for this PIN.")
            .setView(e)
            .setPositiveButton("Save") { _, _ ->
                val v = e.text.toString()
                if (v.length == 4) { Prefs.setStr(this, "pin", v); toast("PIN saved") } else toast("PIN must be 4 digits")
            }.setNegativeButton("Cancel", null).show()
    }

    private fun hideCats(kind: String, title: String) {
        val p = Store.active(this)
        if (p == null) { toast("Add a playlist first"); return }
        toast("Loading categories...")
        Thread {
            val cats = try { Repo.get(p, kind).first } catch (e: Exception) { emptyList() }
            runOnUiThread {
                if (cats.isEmpty()) toast("No categories found") else {
                    val names = cats.map { it.name }.toTypedArray()
                    val hidden = Prefs.getSet(this, "hide_$kind")
                    val checked = BooleanArray(names.size) { hidden.contains(names[it]) }
                    AlertDialog.Builder(this).setTitle(title)
                        .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
                        .setPositiveButton("Save") { _, _ ->
                            val sel = HashSet<String>()
                            for (i in names.indices) if (checked[i]) sel.add(names[i])
                            Prefs.putSet(this, "hide_$kind", sel)
                        }.setNegativeButton("Cancel", null).show()
                }
            }
        }.start()
    }
}
