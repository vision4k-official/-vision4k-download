plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.vision4k.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.vision4k.app"
        minSdk = 21
        targetSdk = 34
        versionCode = 5
        versionName = "2.3"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("vision4k.jks")
            storePassword = "vision4k123"
            keyAlias = "vision4k"
            keyPassword = "vision4k123"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("fixed") }
        release { signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
}
